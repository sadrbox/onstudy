import React, { useEffect, useState } from 'react';
import DataGrid from '../UI/DataGrid';
import ContextWrapper from '../Contexts/ContextProvider';

const Users = () => {
  const [responseData, setResponseData] = useState(undefined);
  const [isLoading, setIsLoading] = useState(true);
  const [dataRows, setDataRows] = useState(undefined);

  const getUsers = async () => {
    try {
      const response = await fetch(
        // 'https://jsonplaceholder.typicode.com/users?_limit=3'
        'https://dummyjson.com/users?limit=3'
      );
      const res = await response.json();
      const data = res.users;
      console.log(data);

      setResponseData(data);
      setDataRows(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoading(false); // Важно: завершить состояние загрузки даже при ошибке
    }
  };

  useEffect(() => {
    getUsers();
  }, []);

  return (
    <>
      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <ContextWrapper dataRows={dataRows}>
          {dataRows && <DataGrid />}
        </ContextWrapper>
      )}
    </>
  );
};

export default Users;
