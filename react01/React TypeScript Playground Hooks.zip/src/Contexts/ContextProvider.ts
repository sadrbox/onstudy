import React, { createContext, useContext, useState, useEffect } from 'react';

type ContextType = {
  context: any; // Используйте правильный тип вместо any
  setContext: React.Dispatch<React.SetStateAction<any>>; // Убедитесь, что тип соответствует вашим данным
};

export const ContextInstance = createContext<ContextType>({
  context: null,
  setContext: () => {},
});

export const useContextProvider = () => {
  return useContext(ContextInstance);
};

export default function ContextWrapper({ children, dataRows }) {
  const [context, setContext] = useState(null);

  useEffect(() => {
    const cols = createDataGridColumns(dataRows[0]);
    if (dataRows) {
      setContext({ cols, dataRows });
    }
  }, [dataRows]);

  // Если контекст еще не установлен, показываем индикатор загрузки
  if (!context) return <>ContextDosNot loading...</>;

  const WrapperProvider = ContextInstance.Provider;
  return (
    <WrapperProvider value={{ context, setContext }}>
      {children}
    </WrapperProvider>
  );
}

function createDataGridColumns(Item) {
  type TItem = (typeof dataRows)[0];
  const keys = Object.keys(Item);
  // console.log(Item['name']);

  // Функция для определения типа данных
  const getType = value => {
    if (typeof value === 'number') {
      return 'number';
    } else if (typeof value === 'boolean') {
      return 'boolean';
    } else if (typeof value === 'string') {
      return 'string';
    } else if (value instanceof Date) {
      return 'date';
    }
    return 'string'; // По умолчанию все остальные типы считаем строками
  };

  // // Генерируем массив колонок на основе ключей и их типов
  const columns = keys.map(key => {
    const sampleValue = Item[key]; // Берем первое значение для определения типа
    // const sampleValue = 'string';
    return {
      field: key, // Имя поля (колонка)
      headerName: key.charAt(0).toUpperCase() + key.slice(1), // Преобразуем в заглавный регистр
      type: getType(sampleValue), // Определяем тип данных
    };
  });

  return columns;
}

export const getType = value => {
  if (typeof value === 'number') {
    return 'number';
  } else if (typeof value === 'boolean') {
    return 'boolean';
  } else if (typeof value === 'string') {
    return 'string';
  } else if (value instanceof Date) {
    return 'date';
  }
  return 'string'; // По умолчанию все остальные типы считаем строками
};
