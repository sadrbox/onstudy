import React, { StrictMode } from 'react';
import * as ReactDOMClient from 'react-dom/client';
// import ErrorBoundary from './components/ErrorBoundary';

// import App from './App';
import Users from './components/Users';

const rootElement = document.getElementById('root');
const root = ReactDOMClient.createRoot(rootElement);

root.render(
  <StrictMode>
    <Users />
  </StrictMode>
);
