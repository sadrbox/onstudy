import React from 'react';
import { useContextProvider } from '../Contexts/ContextProvider';

const DataGrid = () => {
  const { context, setContext } = useContextProvider(); // Данные теперь получаются из контекста

  if (context?.cols) {
    const cols = context?.cols;
    const dataRows = context?.dataRows;
    // console.log(cols);
    // let fields = [];
    return (
      <table>
        <thead>
          <tr>
            {cols &&
              cols.map((column, keyID) => <th key={keyID}>{column.field}</th>)}
          </tr>
        </thead>
        <tbody>
          {dataRows.map(user => (
            <tr key={user.id}>
              {cols.map((column, keyID) => {
                // console.log(user);
                // if(getType().includes(typeof user))
                const value = user[column.field];
                return (
                  <td key={column.field}>
                    {typeof value === 'string' ? value : JSON.stringify(value)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    );
  }
};

export default DataGrid;
